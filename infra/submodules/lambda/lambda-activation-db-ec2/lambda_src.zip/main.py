import os, json, logging, boto3

logger = logging.getLogger()
logger.setLevel(logging.INFO)

ec2 = boto3.client("ec2")
rds = boto3.client("rds")

def unique(seq):
    return list(dict.fromkeys(seq))

# ----------------- Descubrimiento -----------------

def get_all_ec2_ids():
    ids = []
    paginator = ec2.get_paginator("describe_instances")
    for page in paginator.paginate():
        for r in page.get("Reservations", []):
            for inst in r.get("Instances", []):
                st = (inst.get("State", {}) or {}).get("Name")
                if st not in ("shutting-down", "terminated"):
                    ids.append(inst["InstanceId"])
    return unique(ids)

def get_ec2_by_tags(tags):
    if not tags:
        return []
    filters = [{"Name": f"tag:{k}", "Values": [v]} for k, v in tags.items()]
    ids = []
    paginator = ec2.get_paginator("describe_instances")
    for page in paginator.paginate(Filters=filters):
        for r in page.get("Reservations", []):
            for inst in r.get("Instances", []):
                st = (inst.get("State", {}) or {}).get("Name")
                if st not in ("shutting-down", "terminated"):
                    ids.append(inst["InstanceId"])
    return unique(ids)

def get_all_rds_instances():
    ids = []
    paginator = rds.get_paginator("describe_db_instances")
    for page in paginator.paginate():
        for db in page.get("DBInstances", []):
            ids.append(db["DBInstanceIdentifier"])
    return unique(ids)

def get_all_rds_clusters():
    ids = []
    paginator = rds.get_paginator("describe_db_clusters")
    for page in paginator.paginate():
        for cl in page.get("DBClusters", []):
            ids.append(cl["DBClusterIdentifier"])
    return unique(ids)

def get_rds_by_tags(tags):
    if not tags:
        return [], []
    inst_ids, clus_ids = [], []

    paginator = rds.get_paginator("describe_db_instances")
    for page in paginator.paginate():
        for db in page.get("DBInstances", []):
            arn = db["DBInstanceArn"]
            t = rds.list_tags_for_resource(ResourceName=arn)["TagList"]
            kv = {x["Key"]: x["Value"] for x in t}
            if all(k in kv and kv[k] == v for k, v in tags.items()):
                inst_ids.append(db["DBInstanceIdentifier"])

    paginator = rds.get_paginator("describe_db_clusters")
    for page in paginator.paginate():
        for cl in page.get("DBClusters", []):
            arn = cl["DBClusterArn"]
            t = rds.list_tags_for_resource(ResourceName=arn)["TagList"]
            kv = {x["Key"]: x["Value"] for x in t}
            if all(k in kv and kv[k] == v for k, v in tags.items()):
                clus_ids.append(cl["DBClusterIdentifier"])

    return unique(inst_ids), unique(clus_ids)

# ----------------- EC2 helpers -----------------

def split_spot_and_ondemand(ids):
    if not ids:
        return [], []
    # describe_instances acepta hasta 1000 IDs; para simplificar omitimos batch aquí
    desc = ec2.describe_instances(InstanceIds=ids)
    spot, ond = [], []
    for r in desc.get("Reservations", []):
        for i in r.get("Instances", []):
            if i.get("InstanceLifecycle") == "spot":
                spot.append(i["InstanceId"])
            else:
                ond.append(i["InstanceId"])
    return unique(ond), unique(spot)

# ----------------- RDS helpers -----------------

def rds_instance_status(dbid):
    try:
        db = rds.describe_db_instances(DBInstanceIdentifier=dbid)["DBInstances"][0]
        return db.get("DBInstanceStatus", "")
    except Exception:
        return ""

def wait_rds_available(dbid, timeout_s):
    if timeout_s <= 0:
        return False
    waiter = rds.get_waiter("db_instance_available")
    try:
        waiter.wait(DBInstanceIdentifier=dbid, WaiterConfig={"Delay": 15, "MaxAttempts": max(1, timeout_s // 15)})
        return True
    except Exception:
        return False

# ----------------- EC2 actions -----------------

def handle_ec2(action, ec2_ids):
    res = {"ec2": {"requested": ec2_ids, "ok": [], "terminated": [], "skipped": [], "errors": []}}
    if not ec2_ids:
        return res

    terminate_spot_on_off = os.getenv("EC2_TERMINATE_SPOT_ON_OFF", "false").lower() in ("1","true","yes","y","si","sí")

    try:
        ond, spot = split_spot_and_ondemand(ec2_ids)

        # On-Demand → start/stop
        if ond:
            for i in range(0, len(ond), 100):
                chunk = ond[i:i+100]
                if action == "on":
                    ec2.start_instances(InstanceIds=chunk)
                else:
                    ec2.stop_instances(InstanceIds=chunk)
            res["ec2"]["ok"] += ond

        # Spot → terminate en OFF (si flag activado), skip en ON
        if spot:
            if action == "off" and terminate_spot_on_off:
                for i in range(0, len(spot), 100):
                    chunk = spot[i:i+100]
                    ec2.terminate_instances(InstanceIds=chunk)
                res["ec2"]["terminated"] += spot
            else:
                res["ec2"]["skipped"] += spot

    except Exception as e:
        logger.exception("EC2 error")
        res["ec2"]["errors"].append(str(e))
    return res

# ----------------- RDS actions -----------------

def handle_rds(action, rds_inst_ids, rds_cluster_ids):
    res = {
        "rds_instances": {"requested": rds_inst_ids, "ok": [], "unsupported": [], "skipped": [], "errors": []},
        "rds_clusters":  {"requested": rds_cluster_ids, "ok": [], "unsupported": [], "skipped": [], "errors": []},
    }

    try:
        wait_secs = int(os.getenv("RDS_WAIT_AVAILABLE_SECONDS", "0"))
    except ValueError:
        wait_secs = 0

    # Instancias
    for dbid in rds_inst_ids:
        try:
            status = rds_instance_status(dbid)

            if action == "off":
                if status == "available":
                    rds.stop_db_instance(DBInstanceIdentifier=dbid)
                    res["rds_instances"]["ok"].append(dbid)
                elif status in ("stopped", "stopping"):
                    res["rds_instances"]["skipped"].append({dbid: status})
                else:
                    if wait_secs > 0 and wait_rds_available(dbid, wait_secs):
                        rds.stop_db_instance(DBInstanceIdentifier=dbid)
                        res["rds_instances"]["ok"].append(dbid)
                    else:
                        res["rds_instances"]["errors"].append({dbid: f"state={status}; no se pudo detener"})
            else:  # ON
                if status == "stopped":
                    rds.start_db_instance(DBInstanceIdentifier=dbid)
                    res["rds_instances"]["ok"].append(dbid)
                elif status in ("available", "starting"):
                    res["rds_instances"]["skipped"].append({dbid: status})
                else:
                    res["rds_instances"]["errors"].append({dbid: f"state={status}; no se pudo iniciar"})
        except Exception as e:
            msg = str(e)
            logger.exception("RDS Instance error for %s", dbid)
            if "cannot be stopped" in msg.lower() or "not supported" in msg.lower():
                res["rds_instances"]["unsupported"].append({dbid: msg})
            else:
                res["rds_instances"]["errors"].append({dbid: msg})

    # Clusters (Aurora) — sin espera fina (podrías añadir waiters si quieres)
    for clid in rds_cluster_ids:
        try:
            if action == "on":
                rds.start_db_cluster(DBClusterIdentifier=clid)
            else:
                rds.stop_db_cluster(DBClusterIdentifier=clid)
            res["rds_clusters"]["ok"].append(clid)
        except Exception as e:
            msg = str(e)
            logger.exception("RDS Cluster error for %s", clid)
            if "cannot be stopped" in msg.lower() or "not supported" in msg.lower():
                res["rds_clusters"]["unsupported"].append({clid: msg})
            else:
                res["rds_clusters"]["errors"].append({clid: msg})
    return res

# ----------------- Handler -----------------

def build_response(code, body):
    return {
        "statusCode": code,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(body),
        "isBase64Encoded": False,
    }

def handler(event, context):
    logger.info("Event: %s", json.dumps(event))

    path = (event.get("path") or "").lower()
    action = "on" if path.endswith("/on") else "off" if path.endswith("/off") else None
    if not action:
        return build_response(400, {"error": "Ruta inválida. Use POST /on o /off"})

    ec2_ids_env     = os.getenv("EC2_INSTANCE_IDS", "")
    rds_ids_env     = os.getenv("RDS_INSTANCE_IDS", "")
    target_tags_env = os.getenv("TARGET_TAGS_JSON", "{}")

    try:
        target_tags = json.loads(target_tags_env) if target_tags_env else {}
    except json.JSONDecodeError:
        target_tags = {}

    ec2_ids         = [i.strip() for i in ec2_ids_env.split(",") if i.strip()]
    rds_inst_ids    = [i.strip() for i in rds_ids_env.split(",") if i.strip()]
    rds_cluster_ids = []

    # Descubrimiento por tags
    if target_tags:
        ec2_ids = unique(ec2_ids + get_ec2_by_tags(target_tags))
        inst_by_tag, clus_by_tag = get_rds_by_tags(target_tags)
        rds_inst_ids    = unique(rds_inst_ids + inst_by_tag)
        rds_cluster_ids = unique(rds_cluster_ids + clus_by_tag)

    # Si no se pasó nada, tomar TODO en la región
    if not ec2_ids and not target_tags:
        ec2_ids = get_all_ec2_ids()
    if not rds_inst_ids and not rds_cluster_ids and not target_tags:
        rds_inst_ids    = get_all_rds_instances()
        rds_cluster_ids = get_all_rds_clusters()

    result = {
        "action": action,
        "targets": {
            "ec2": ec2_ids,
            "rds_instances": rds_inst_ids,
            "rds_clusters": rds_cluster_ids
        }
    }

    result.update(handle_ec2(action, ec2_ids))
    result.update(handle_rds(action, rds_inst_ids, rds_cluster_ids))

    return build_response(200, result)
